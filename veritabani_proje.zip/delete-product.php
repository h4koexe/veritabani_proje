<?php
require_once 'includes/config.php';
session_start();

if (!isset($_SESSION['admin'])) {
    die("Yetkisiz erişim!");
}

$id = $_GET['id'] ?? null;

$stmt = $pdo->prepare("DELETE FROM products WHERE id = ?");
$stmt->execute([$id]);

header("Location: admin_panel.php");
exit;
