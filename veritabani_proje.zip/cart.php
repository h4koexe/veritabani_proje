<?php
require_once 'includes/config.php';
require_once 'includes/functions.php';
requireLogin();

$user_id = $_SESSION['user_id'];
$items = getCartItems($pdo, $user_id);
$total = getCartTotal($pdo, $user_id);


// Ürün ekleme işlemi
if (isset($_GET['add'])) {
    $product_id = (int)$_GET['add'];

    // Bu ürün zaten sepette var mı kontrol et
    $check = $pdo->prepare("SELECT * FROM cart WHERE user_id = ? AND product_id = ?");
    $check->execute([$user_id, $product_id]);

    if ($check->rowCount() > 0) {
        // Varsa miktarı artır
        $pdo->prepare("UPDATE cart SET quantity = quantity + 1 WHERE user_id = ? AND product_id = ?")
            ->execute([$user_id, $product_id]);
    } else {
        // Yoksa yeni satır ekle
        $pdo->prepare("INSERT INTO cart (user_id, product_id, quantity) VALUES (?, ?, 1)")
            ->execute([$user_id, $product_id]);
    }

    header("Location: cart.php");
    exit;
}
// Ürün silme
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['remove_id'])) {
    $remove_id = $_POST['remove_id'];
    $stmt = $pdo->prepare("DELETE FROM cart WHERE id = ? AND user_id = ?");
    $stmt->execute([$remove_id, $user_id]);
    header("Location: cart.php");
    exit;
}
?>

<!DOCTYPE html>
<html lang="tr">
<head>
  <meta charset="UTF-8">
  <title>Sepetim - Trimecha</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
  <style>
    .hero {
      background: linear-gradient(to right, #3b5998, #ff6600);
      color: white;
      padding: 40px 20px;
      text-align: center;
    }
    .btn-orange {
      background-color: #ff6600;
      color: white;
    }
    .btn-orange:hover {
      background-color: #e65c00;
      color: white;
    }
  </style>
</head>
<body class="bg-light">

<!-- Navbar -->
<nav class="navbar navbar-expand-lg bg-white border-bottom">
  <div class="container">
    <a class="navbar-brand fw-bold text-danger" href="index.php">TrimechA</a>
    <div class="d-flex">
      <a href="dashboard.php" class="btn btn-outline-primary btn-sm me-2">Panel</a>
      <a href="logout.php" class="btn btn-outline-danger btn-sm">Çıkış</a>
    </div>
  </div>
</nav>

<!-- Hero -->
<section class="hero">
  <h1 class="display-6 fw-bold">Sepetim</h1>
  <p class="lead">Satın almak üzere seçtiğiniz ürünler burada listeleniyor.</p>
</section>

<div class="container my-5">
  <?php if (count($items) > 0): ?>
    <div class="table-responsive">
      <table class="table table-hover align-middle">
        <thead class="table-dark">
          <tr>
            <th>Ürün</th>
            <th>Fiyat</th>
            <th>Adet</th>
            <th>Toplam</th>
            <th></th>
          </tr>
        </thead>
        <tbody>
          <?php foreach ($items as $item): ?>
            <tr>
              <td class="fw-bold">
                <img src="<?= htmlspecialchars($item['image']) ?>" alt="<?= htmlspecialchars($item['name']) ?>" width="60" class="me-2 rounded">
                <?= htmlspecialchars($item['name']) ?>
              </td>
              <td>₺<?= number_format($item['price'], 2) ?></td>
              <td><?= $item['quantity'] ?></td>
              <td>₺<?= number_format($item['price'] * $item['quantity'], 2) ?></td>
              <td>
                <form method="POST">
                  <input type="hidden" name="remove_id" value="<?= $item['id'] ?>">
                  <button type="submit" class="btn btn-sm btn-danger">Sil</button>
                </form>
              </td>
            </tr>
          <?php endforeach; ?>
        </tbody>
      </table>
    </div>

    <div class="text-end">
      <h4 class="fw-bold">Toplam: ₺<?= number_format($total, 2) ?></h4>
      <a href="checkout.php" class="btn btn-success">Siparişi Onayla</a>
    </div>
  <?php else: ?>
    <div class="alert alert-warning">Sepetinizde ürün bulunmamaktadır.</div>
  <?php endif; ?>

  <div class="text-start mt-4 d-flex gap-3">
    <a href="index.php" class="btn btn-outline-secondary">← Alışverişe Devam Et</a>
    <a href="listing.php" class="btn btn-orange">+ Yeni Ürün Ekle</a>
  </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
