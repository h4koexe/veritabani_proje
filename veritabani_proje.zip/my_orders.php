<?php
require_once 'includes/config.php';
require_once 'includes/functions.php';
requireLogin();

$user_id = $_SESSION['user_id'];
$stmt = $pdo->prepare("SELECT * FROM orders WHERE user_id = ? ORDER BY created_at DESC");
$stmt->execute([$user_id]);
$orders = $stmt->fetchAll();
?>

<!DOCTYPE html>
<html lang="tr">
<head>
  <meta charset="UTF-8">
  <title>Siparişlerim - Trimecha</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
  <style>
    .hero {
      background: linear-gradient(to right, #3b5998, #ff6600);
      color: white;
      padding: 40px 20px;
      text-align: center;
    }
  </style>
</head>
<body class="bg-light">

<nav class="navbar navbar-expand-lg bg-white border-bottom">
  <div class="container">
    <a class="navbar-brand fw-bold text-danger" href="index.php">TrimechA</a>
    <div class="d-flex">
      <a href="dashboard.php" class="btn btn-outline-primary btn-sm me-2">Panel</a>
      <a href="logout.php" class="btn btn-outline-danger btn-sm">Çıkış</a>
    </div>
  </div>
</nav>

<section class="hero">
  <h1 class="display-6 fw-bold">Siparişlerim</h1>
  <p class="lead">Geçmiş tüm siparişlerinizi burada görüntüleyebilirsiniz.</p>
</section>

<div class="container my-5">
  <?php if (count($orders) > 0): ?>
    <div class="table-responsive">
      <table class="table table-bordered align-middle">
        <thead class="table-dark">
          <tr>
            <th>Sipariş No</th>
            <th>Tarih</th>
            <th>Tutar</th>
            <th>Durum</th>
          </tr>
        </thead>
        <tbody>
          <?php foreach ($orders as $order): ?>
            <tr>
              <td><?= htmlspecialchars($order['id']) ?></td>
              <td><?= htmlspecialchars($order['created_at']) ?></td>
              <td>₺<?= number_format($order['total'], 2) ?></td>
              <td><?= htmlspecialchars($order['status']) ?></td>
            </tr>
          <?php endforeach; ?>
        </tbody>
      </table>
    </div>
  <?php else: ?>
    <div class="alert alert-warning">Henüz bir siparişiniz bulunmamaktadır.</div>
  <?php endif; ?>

  <a href="dashboard.php" class="btn btn-outline-secondary mt-4">← Panele Dön</a>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
