<?php
session_start();
require_once 'includes/config.php';

// Admin girişi kontrol
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['admin_login'])) {
    $email = $_POST['email'] ?? '';
    $pass = $_POST['password'] ?? '';

    $stmt = $pdo->prepare("SELECT * FROM admins WHERE email = ?");
    $stmt->execute([$email]);
    $admin = $stmt->fetch();

    if ($admin && password_verify($pass, $admin['password'])) {
        $_SESSION['admin'] = true;
    } else {
        $message = "Giriş başarısız!";
    }
}

if (isset($_GET['logout'])) {
    unset($_SESSION['admin']);
    header("Location: admin_panel.php");
    exit;
}

if (!isset($_SESSION['admin'])):
?>

<!-- Admin Giriş Ekranı -->
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Admin Giriş - Trimecha</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="bg-light">
<div class="container mt-5">
    <div class="row justify-content-center">
        <div class="col-md-5">
            <div class="card shadow">
                <div class="card-body">
                    <h3 class="card-title mb-4">Admin Giriş</h3>
                    <?php if (!empty($message)) echo '<div class="alert alert-danger">'.$message.'</div>'; ?>
                    <form method="POST">
                        <div class="mb-3">
                            <label class="form-label">E-posta</label>
                            <input type="email" name="email" class="form-control" required>
                        </div>
                        <div class="mb-3">
                            <label class="form-label">Şifre</label>
                            <input type="password" name="password" class="form-control" required>
                        </div>
                        <button type="submit" name="admin_login" class="btn btn-primary w-100">Giriş Yap</button>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
</body>
</html>

<?php exit; endif; ?>

<!-- Admin Paneli -->
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Admin Panel - Trimecha</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="bg-light">

<div class="container mt-4">
    <div class="d-flex justify-content-between align-items-center mb-4">
        <h2>Trimecha Admin Panel</h2>
        <a href="?logout=1" class="btn btn-danger">Çıkış Yap</a>
    </div>

    <!-- Ürün Ekle -->
    <div class="card mb-4 shadow">
        <div class="card-header bg-primary text-white">Yeni Ürün Ekle</div>
        <div class="card-body">
            <form method="POST" action="admin_save.php">
                <input type="hidden" name="action" value="add_product">
                <div class="mb-3">
                    <input type="text" name="name" placeholder="Ürün Adı" class="form-control" required>
                </div>
                <div class="mb-3">
                    <textarea name="description" placeholder="Açıklama" class="form-control"></textarea>
                </div>
                <div class="mb-3">
                    <input type="number" step="0.01" name="price" placeholder="Fiyat" class="form-control" required>
                </div>
                <div class="mb-3 d-flex gap-3">
                    <select name="category_id" class="form-select">
                        <?php foreach ($pdo->query("SELECT * FROM categories") as $cat): ?>
                            <option value="<?= $cat['id'] ?>"><?= $cat['name'] ?></option>
                        <?php endforeach; ?>
                    </select>
                    <select name="brand_id" class="form-select">
                        <?php foreach ($pdo->query("SELECT * FROM brands") as $brand): ?>
                            <option value="<?= $brand['id'] ?>"><?= $brand['name'] ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div class="mb-3">
                    <input type="text" name="image" placeholder="Resim Yolu (images/xxx.jpg)" class="form-control">
                </div>
                <button type="submit" class="btn btn-success">Ekle</button>
            </form>
        </div>
    </div>

    <!-- Kategori / Marka / Hizmet -->
    <div class="row g-3 mb-4">
        <div class="col-md-4">
            <div class="card shadow">
                <div class="card-header bg-secondary text-white">Kategori Ekle</div>
                <div class="card-body">
                    <form method="POST" action="admin_save.php">
                        <input type="hidden" name="action" value="add_category">
                        <input type="text" name="name" class="form-control mb-2" required>
                        <button type="submit" class="btn btn-outline-dark w-100">Ekle</button>
                    </form>
                </div>
            </div>
        </div>
        <div class="col-md-4">
            <div class="card shadow">
                <div class="card-header bg-secondary text-white">Marka Ekle</div>
                <div class="card-body">
                    <form method="POST" action="admin_save.php">
                        <input type="hidden" name="action" value="add_brand">
                        <input type="text" name="name" class="form-control mb-2" required>
                        <button type="submit" class="btn btn-outline-dark w-100">Ekle</button>
                    </form>
                </div>
            </div>
        </div>
        <div class="col-md-4">
            <div class="card shadow">
                <div class="card-header bg-secondary text-white">Hizmet Ekle</div>
                <div class="card-body">
                    <form method="POST" action="admin_save.php">
                        <input type="hidden" name="action" value="add_service">
                        <input type="text" name="name" class="form-control mb-2" placeholder="Hizmet Adı" required>
                        <textarea name="description" class="form-control mb-2" placeholder="Açıklama"></textarea>
                        <input type="number" step="0.01" name="price" class="form-control mb-2" placeholder="Fiyat" required>
                        <button type="submit" class="btn btn-outline-dark w-100">Ekle</button>
                    </form>
                </div>
            </div>
        </div>
    </div>

    <!-- Ürün Listesi -->
    <div class="card shadow">
        <div class="card-header bg-dark text-white">Ürün Listesi</div>
        <div class="card-body">
            <table class="table table-striped table-bordered align-middle">
                <thead>
                    <tr>
                        <th>Ad</th>
                        <th>Fiyat</th>
                        <th>Kategori</th>
                        <th>Marka</th>
                        <th>İşlem</th>
                    </tr>
                </thead>
                <tbody>
                    <?php
                    $stmt = $pdo->query("SELECT p.*, c.name AS cat_name, b.name AS brand_name
                                         FROM products p
                                         LEFT JOIN categories c ON p.category_id = c.id
                                         LEFT JOIN brands b ON p.brand_id = b.id");
                    foreach ($stmt as $product): ?>
                        <tr>
                            <td><?= htmlspecialchars($product['name']) ?></td>
                            <td>₺<?= number_format($product['price'], 2) ?></td>
                            <td><?= htmlspecialchars($product['cat_name']) ?></td>
                            <td><?= htmlspecialchars($product['brand_name']) ?></td>
                            <td>
                                <a href="edit_product.php?id=<?= $product['id'] ?>" class="btn btn-sm btn-warning">Düzenle</a>
                                <a href="delete_product.php?id=<?= $product['id'] ?>" class="btn btn-sm btn-danger" onclick="return confirm('Silmek istediğinize emin misiniz?');">Sil</a>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

</body>
</html>
