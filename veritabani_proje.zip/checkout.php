<?php
require_once 'includes/config.php';
require_once 'includes/functions.php';
requireLogin();

$user_id = $_SESSION['user_id'];
$items = getCartItems($pdo, $user_id);
$total = getCartTotal($pdo, $user_id);

// Sepet boşsa işlemi engelle
if (count($items) === 0) {
    header("Location: cart.php?error=empty_cart");
    exit;
}

// 1. Siparişi oluştur
$stmt = $pdo->prepare("INSERT INTO orders (user_id, total_amount) VALUES (?, ?)");
$stmt->execute([$user_id, $total]);
$order_id = $pdo->lastInsertId();

// 2. Siparişe ait ürünleri kaydet
foreach ($items as $item) {
    $stmt = $pdo->prepare("INSERT INTO order_items (order_id, product_id, quantity, price) VALUES (?, ?, ?, ?)");
    $stmt->execute([$order_id, $item['product_id'], $item['quantity'], $item['price']]);
}

// 3. Kullanıcının sepetini temizle
$stmt = $pdo->prepare("DELETE FROM cart WHERE user_id = ?");
$stmt->execute([$user_id]);

// 4. Başarılı sipariş sonrası yönlendir
header("Location: my_orders.php?success=1");
exit;
