<?php
require_once 'includes/config.php';
require_once 'includes/functions.php';
requireLogin();

$user_id = $_SESSION['user_id'];
$username = getUserName($pdo, $user_id);
?>

<!DOCTYPE html>
<html lang="tr">
<head>
  <meta charset="UTF-8">
  <title>Kontrol Paneli - Trimecha</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
  <style>
    .hero {
      background: linear-gradient(to right, #3b5998, #ff6600);
      color: white;
      padding: 40px 20px;
      text-align: center;
    }
    .dashboard-card {
      transition: 0.3s;
    }
    .dashboard-card:hover {
      transform: translateY(-5px);
    }
  </style>
</head>
<body class="bg-light">

<!-- Navbar -->
<nav class="navbar navbar-expand-lg bg-white border-bottom">
  <div class="container">
    <a class="navbar-brand fw-bold text-danger" href="index.php">TrimechA</a>
    <div class="d-flex">
      <a href="logout.php" class="btn btn-outline-danger btn-sm">Çıkış</a>
    </div>
  </div>
</nav>

<!-- Hero -->
<section class="hero">
  <h1 class="display-6 fw-bold">Merhaba, <?= htmlspecialchars($username) ?></h1>
  <p class="lead">Trimecha kullanıcı paneline hoş geldiniz.</p>
</section>

<div class="container my-5">
  <div class="row g-4">
    <div class="col-md-3">
      <a href="profile.php" class="text-decoration-none">
        <div class="card shadow-sm dashboard-card text-center p-3">
          <h5 class="card-title">👤 Profilim</h5>
        </div>
      </a>
    </div>
    <div class="col-md-3">
      <a href="my_orders.php" class="text-decoration-none">
        <div class="card shadow-sm dashboard-card text-center p-3">
          <h5 class="card-title">📦 Siparişlerim</h5>
        </div>
      </a>
    </div>
    <div class="col-md-3">
      <a href="favorites.php" class="text-decoration-none">
        <div class="card shadow-sm dashboard-card text-center p-3">
          <h5 class="card-title">❤️ Favorilerim</h5>
        </div>
      </a>
    </div>
    <div class="col-md-3">
      <a href="cart.php" class="text-decoration-none">
        <div class="card shadow-sm dashboard-card text-center p-3">
          <h5 class="card-title">🛒 Sepetim</h5>
        </div>
      </a>
    </div>
  </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>