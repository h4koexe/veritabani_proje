<?php
session_start();
require_once 'includes/config.php';
require_once 'includes/functions.php';

$user_id = $_SESSION['user_id'] ?? null;
$username = $user_id ? getUserName($pdo, $user_id) : null;

$categories = $pdo->query("SELECT * FROM categories LIMIT 5")->fetchAll();
$products = getProducts($pdo);
$services = $pdo->query("SELECT * FROM services")->fetchAll();

// Favorilere ekleme
$showFavModal = false;

if (isset($_GET['fav']) && $user_id) {
    $product_id = (int)$_GET['fav'];
    $check = $pdo->prepare("SELECT id FROM favorites WHERE user_id = ? AND product_id = ?");
    $check->execute([$user_id, $product_id]);

    if ($check->rowCount() === 0) {
        $insert = $pdo->prepare("INSERT INTO favorites (user_id, product_id) VALUES (?, ?)");
        $insert->execute([$user_id, $product_id]);
        $showFavModal = true;
    }
}
?>

<!DOCTYPE html>
<html lang="tr">
<head>
  <meta charset="UTF-8">
  <title>Trimecha - Ana Sayfa</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
  <style>
    .hero {
      background: linear-gradient(to right, #3b5998, #ff6600);
      color: white;
      padding: 60px 20px;
      text-align: center;
    }
    .btn-orange {
      background-color: #ff6600;
      color: white;
    }
    .btn-orange:hover {
      background-color: #e65c00;
      color: white;
    }
    .card-img-top {
      height: 200px;
      object-fit: cover;
    }
  </style>
</head>
<body class="bg-light">

<!-- Navbar -->
<nav class="navbar navbar-expand-lg bg-white border-bottom">
  <div class="container">
    <a class="navbar-brand fw-bold text-danger" href="#">Trimecha</a>
    <div class="collapse navbar-collapse">
      <ul class="navbar-nav me-auto">
        <li class="nav-item"><a href="#" class="nav-link">Ana Sayfa</a></li>
        <li class="nav-item"><a href="categories.php" class="nav-link">Kategoriler</a></li>
        <li class="nav-item"><a href="listing.php" class="nav-link">Tüm Ürünler</a></li>
        <li class="nav-item"><a href="#services" class="nav-link">Tamir Hizmetleri</a></li>
      </ul>
      <form class="d-flex me-3">
        <input class="form-control me-2" type="search" placeholder="Ürün ara..." aria-label="Ara">
        <button class="btn btn-outline-primary" type="submit">Ara</button>
      </form>
      <?php if ($username): ?>
        <span class="me-2">👤 <?= htmlspecialchars($username) ?></span>
        <a href="dashboard.php" class="btn btn-outline-primary btn-sm me-1">Panel</a>
        <a href="logout.php" class="btn btn-outline-danger btn-sm">Çıkış</a>
      <?php else: ?>
        <a href="login.php" class="btn btn-outline-primary btn-sm me-1">Giriş Yap</a>
        <a href="register.php" class="btn btn-outline-primary btn-sm">Üye Ol</a>
      <?php endif; ?>
    </div>
  </div>
</nav>

<!-- Hero -->
<section class="hero">
  <h1 class="display-5 fw-bold">Bilgisayar Satış ve Tamir Hizmetleri</h1>
  <p class="lead">En kaliteli bilgisayar parçaları ve profesyonel tamir hizmetleri tek adreste!</p>
  <a href="listing.php" class="btn btn-light btn-lg me-2">Ürünleri İncele</a>
  <a href="#services" class="btn btn-outline-light btn-lg">Tamir Hizmetleri</a>
</section>

<!-- Kategoriler -->
<div class="container my-5">
  <h4 class="mb-3 fw-bold">Kategoriler</h4>
  <div class="d-flex flex-wrap gap-2">
    <?php foreach ($categories as $cat): ?>
      <a href="categories.php?category_id=<?= $cat['id'] ?>" class="btn btn-light border">
        <i class="bi bi-cpu-fill"></i> <?= htmlspecialchars($cat['name']) ?>
      </a>
    <?php endforeach; ?>
  </div>
</div>

<!-- Ürünler -->
<div class="container mb-5">
  <h4 class="mb-3 fw-bold">Yeni Ürünler</h4>
  <div class="row">
    <?php foreach (array_slice($products, 0, 6) as $product): ?>
      <div class="col-md-4 mb-4">
        <div class="card shadow-sm h-100">
          <img src="<?= htmlspecialchars($product['image']) ?>" class="card-img-top" alt="<?= $product['name'] ?>">
          <div class="card-body d-flex flex-column">
            <h5 class="card-title"><?= htmlspecialchars($product['name']) ?></h5>
            <p class="card-text text-muted small"><?= htmlspecialchars($product['description']) ?></p>
            <p class="card-text fw-bold">₺<?= number_format($product['price'], 2) ?></p>
            <form action="cart.php" method="get" class="mt-auto">
              <input type="hidden" name="add" value="<?= $product['id'] ?>">
              <button type="submit" class="btn btn-orange btn-sm w-100">🛒 Sepete Ekle</button>
            </form>
            <a href="index.php?fav=<?= $product['id'] ?>" class="btn btn-outline-danger btn-sm mt-2 w-100">❤️ Favorilerim</a>
          </div>
        </div>
      </div>
    <?php endforeach; ?>
  </div>
</div>

<!-- Hizmetler -->
<div class="container mb-5" id="services">
  <h4 class="mb-4 fw-bold">Tamir Hizmetlerimiz</h4>
  <div class="row">
    <?php foreach ($services as $service): ?>
      <div class="col-md-4 mb-3">
        <div class="card text-center border shadow-sm h-100">
          <div class="card-body">
            <h5 class="card-title"><?= htmlspecialchars($service['name']) ?></h5>
            <p class="card-text"><?= htmlspecialchars($service['description']) ?></p>
            <p class="fw-bold text-success">₺<?= number_format($service['price'], 2) ?></p>
          </div>
        </div>
      </div>
    <?php endforeach; ?>
  </div>
  <div class="text-center mt-3">
    <a href="services.php" class="btn btn-orange">Tüm Hizmetleri Gör</a>
  </div>
</div>

<!-- Modal -->
<div class="modal fade" id="favModal" tabindex="-1" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered">
    <div class="modal-content text-center p-4">
      <div class="modal-body">
        <h5 class="text-success">✔️ Ürün favorilere eklendi!</h5>
      </div>
    </div>
  </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>

<?php if ($showFavModal): ?>
<script>
  const favModal = new bootstrap.Modal(document.getElementById('favModal'));
  favModal.show();
  setTimeout(() => {
    favModal.hide();
  }, 2000);
</script>
<?php endif; ?>

</body>
</html>
