<?php
session_start();
require_once '../includes/config.php';
require_once '../includes/functions.php';

// Sadece giriş yapmış admin erişebilir
if (!isset($_SESSION['admin_id'])) {
    header('Location: login.php');
    exit;
}

// İstatistik verileri
$total_users = $pdo->query("SELECT COUNT(*) FROM users")->fetchColumn();
$total_products = $pdo->query("SELECT COUNT(*) FROM products")->fetchColumn();
$total_orders = $pdo->query("SELECT COUNT(*) FROM orders")->fetchColumn();
$total_services = $pdo->query("SELECT COUNT(*) FROM services")->fetchColumn();
?>

<!DOCTYPE html>
<html lang="tr">
<head>
  <meta charset="UTF-8">
  <title>Yönetici Paneli - Trimecha</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="bg-light">

<nav class="navbar navbar-dark bg-dark mb-4">
  <div class="container">
    <a class="navbar-brand" href="#">Trimecha Admin</a>
    <a href="logout.php" class="btn btn-outline-light btn-sm">Çıkış Yap</a>
  </div>
</nav>

<div class="container">
  <div class="row text-center">
    <div class="col-md-3 mb-3">
      <div class="card shadow-sm">
        <div class="card-body">
          <h5>Kullanıcılar</h5>
          <p class="display-6"><?= $total_users ?></p>
        </div>
      </div>
    </div>
    <div class="col-md-3 mb-3">
      <div class="card shadow-sm">
        <div class="card-body">
          <h5>Ürünler</h5>
          <p class="display-6"><?= $total_products ?></p>
        </div>
      </div>
    </div>
    <div class="col-md-3 mb-3">
      <div class="card shadow-sm">
        <div class="card-body">
          <h5>Siparişler</h5>
          <p class="display-6"><?= $total_orders ?></p>
        </div>
      </div>
    </div>
    <div class="col-md-3 mb-3">
      <div class="card shadow-sm">
        <div class="card-body">
          <h5>Tamirler</h5>
          <p class="display-6"><?= $total_services ?></p>
        </div>
      </div>
    </div>
  </div>
</div>

</body>
</html>
