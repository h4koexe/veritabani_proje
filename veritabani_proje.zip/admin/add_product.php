<?php
session_start();
require_once '../includes/config.php';
if (!isset($_SESSION['admin_id'])) {
    header("Location: login.php");
    exit;
}
$categories = $pdo->query("SELECT * FROM categories")->fetchAll();
$brands = $pdo->query("SELECT * FROM brands")->fetchAll();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = $_POST['name'] ?? '';
    $description = $_POST['description'] ?? '';
    $price = $_POST['price'] ?? 0;
    $category_id = $_POST['category_id'] ?? null;
    $brand_id = $_POST['brand_id'] ?? null;
    $image = $_POST['image'] ?? '';

    $stmt = $pdo->prepare("INSERT INTO products (name, description, price, category_id, brand_id, image)
                           VALUES (?, ?, ?, ?, ?, ?)");
    $stmt->execute([$name, $description, $price, $category_id, $brand_id, $image]);
    $success = true;
}
?>

<!DOCTYPE html>
<html lang="tr">
<head>
  <meta charset="UTF-8">
  <title>Ürün Ekle</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="bg-light">
<div class="container my-5">
  <h3 class="mb-4">Yeni Ürün Ekle</h3>
  <?php if (!empty($success)): ?>
    <div class="alert alert-success">Ürün başarıyla eklendi.</div>
  <?php endif; ?>
  <form method="post">
    <div class="mb-3">
      <label>Ürün Adı</label>
      <input type="text" name="name" class="form-control" required>
    </div>
    <div class="mb-3">
      <label>Açıklama</label>
      <textarea name="description" class="form-control" required></textarea>
    </div>
    <div class="mb-3">
      <label>Fiyat</label>
      <input type="number" step="0.01" name="price" class="form-control" required>
    </div>
    <div class="mb-3">
      <label>Kategori</label>
      <select name="category_id" class="form-select">
        <?php foreach ($categories as $c): ?>
          <option value="<?= $c['id'] ?>"><?= $c['name'] ?></option>
        <?php endforeach; ?>
      </select>
    </div>
    <div class="mb-3">
      <label>Marka</label>
      <select name="brand_id" class="form-select">
        <?php foreach ($brands as $b): ?>
          <option value="<?= $b['id'] ?>"><?= $b['name'] ?></option>
        <?php endforeach; ?>
      </select>
    </div>
    <div class="mb-3">
      <label>Görsel URL</label>
      <input type="text" name="image" class="form-control">
    </div>
    <button class="btn btn-success">Kaydet</button>
  </form>
</div>
</body>
</html>
