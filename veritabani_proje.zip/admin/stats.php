<?php
session_start();
require_once '../includes/config.php';
if (!isset($_SESSION['admin_id'])) {
    header("Location: login.php");
    exit;
}
$total_users = $pdo->query("SELECT COUNT(*) FROM users")->fetchColumn();
$total_products = $pdo->query("SELECT COUNT(*) FROM products")->fetchColumn();
$total_orders = $pdo->query("SELECT COUNT(*) FROM orders")->fetchColumn();
?>

<!DOCTYPE html>
<html lang="tr">
<head>
  <meta charset="UTF-8">
  <title>Yönetici Paneli</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="bg-light">
<div class="container my-5">
  <h3 class="mb-4">İstatistikler</h3>
  <div class="row text-center">
    <div class="col-md-4">
      <div class="bg-primary text-white p-4 rounded">Toplam Kullanıcı: <h2><?= $total_users ?></h2></div>
    </div>
    <div class="col-md-4">
      <div class="bg-success text-white p-4 rounded">Toplam Ürün: <h2><?= $total_products ?></h2></div>
    </div>
    <div class="col-md-4">
      <div class="bg-warning text-dark p-4 rounded">Toplam Sipariş: <h2><?= $total_orders ?></h2></div>
    </div>
  </div>
</div>
</body>
</html>
