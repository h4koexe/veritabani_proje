<?php
require_once 'includes/config.php';
require_once 'includes/functions.php';
requireLogin();

$user_id = $_SESSION['user_id'];
$favorites = getFavorites($pdo, $user_id);
?>

<!DOCTYPE html>
<html lang="tr">
<head>
  <meta charset="UTF-8">
  <title>Favorilerim - Trimecha</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
  <style>
    .hero {
      background: linear-gradient(to right, #3b5998, #ff6600);
      color: white;
      padding: 40px 20px;
      text-align: center;
    }
    .card-img-top {
      height: 180px;
      object-fit: cover;
    }
  </style>
</head>
<body class="bg-light">

<!-- Navbar -->
<nav class="navbar navbar-expand-lg bg-white border-bottom">
  <div class="container">
    <a class="navbar-brand fw-bold text-danger" href="index.php">TrimechA</a>
    <div class="d-flex">
      <a href="dashboard.php" class="btn btn-outline-primary btn-sm me-2">Panel</a>
      <a href="logout.php" class="btn btn-outline-danger btn-sm">Çıkış</a>
    </div>
  </div>
</nav>

<!-- Hero -->
<section class="hero">
  <h1 class="display-6 fw-bold">Favorilerim</h1>
  <p class="lead">Beğendiğiniz ürünler burada listelenir.</p>
</section>

<div class="container my-5">
  <?php if (count($favorites) > 0): ?>
    <div class="row">
      <?php foreach ($favorites as $fav): ?>
        <div class="col-md-4 mb-4">
          <div class="card h-100 shadow-sm">
            <img src="<?= htmlspecialchars($fav['image']) ?>" class="card-img-top" alt="<?= htmlspecialchars($fav['name']) ?>">
            <div class="card-body d-flex flex-column">
              <h5 class="card-title"><?= htmlspecialchars($fav['name']) ?></h5>
              <p class="card-text">₺<?= number_format($fav['price'], 2) ?></p>
              <form action="cart.php" method="get" class="mt-auto">
                <input type="hidden" name="add" value="<?= $fav['product_id'] ?>">
                <button type="submit" class="btn btn-primary btn-sm w-100">Sepete Ekle</button>
              </form>
            </div>
          </div>
        </div>
      <?php endforeach; ?>
    </div>
  <?php else: ?>
    <div class="alert alert-info">Henüz favori ürününüz bulunmamaktadır.</div>
  <?php endif; ?>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
