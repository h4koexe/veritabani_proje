<?php
require_once 'includes/config.php';
session_start();

if (!isset($_SESSION['admin'])) {
    die("Yetkisiz erişim!");
}

$action = $_POST['action'] ?? '';

switch ($action) {
    case 'add_product':
        $stmt = $pdo->prepare("INSERT INTO products (name, description, price, category_id, brand_id, image) VALUES (?, ?, ?, ?, ?, ?)");
        $stmt->execute([
            $_POST['name'], $_POST['description'], $_POST['price'],
            $_POST['category_id'], $_POST['brand_id'], $_POST['image']
        ]);
        break;

    case 'add_category':
        $stmt = $pdo->prepare("INSERT INTO categories (name) VALUES (?)");
        $stmt->execute([$_POST['name']]);
        break;

    case 'add_brand':
        $stmt = $pdo->prepare("INSERT INTO brands (name) VALUES (?)");
        $stmt->execute([$_POST['name']]);
        break;

    case 'add_service':
        $stmt = $pdo->prepare("INSERT INTO services (name, description, price) VALUES (?, ?, ?)");
        $stmt->execute([
            $_POST['name'], $_POST['description'], $_POST['price']
        ]);
        break;
}

header("Location: admin_panel.php");
exit;
