<?php
session_start();
require_once 'includes/config.php';

if (!isset($_SESSION['admin'])) {
    header("Location: admin_panel.php");
    exit;
}

$product_id = $_GET['id'] ?? null;

if (!$product_id) {
    die("Ürün ID'si eksik.");
}

$stmt = $pdo->prepare("SELECT * FROM products WHERE id = ?");
$stmt->execute([$product_id]);
$product = $stmt->fetch();

if (!$product) {
    die("Ürün bulunamadı.");
}

// Form gönderildiğinde güncelle
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = $_POST['name'] ?? '';
    $description = $_POST['description'] ?? '';
    $price = $_POST['price'] ?? 0;
    $category_id = $_POST['category_id'] ?? 0;
    $brand_id = $_POST['brand_id'] ?? 0;
    $image = $_POST['image'] ?? '';

    $stmt = $pdo->prepare("UPDATE products SET name=?, description=?, price=?, category_id=?, brand_id=?, image=? WHERE id=?");
    $stmt->execute([$name, $description, $price, $category_id, $brand_id, $image, $product_id]);

    header("Location: admin_panel.php");
    exit;
}
?>

<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Ürün Düzenle - Trimecha</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="bg-light">

<div class="container mt-4">
    <h3 class="mb-4">Ürünü Düzenle</h3>

    <form method="POST" class="card shadow p-4">
        <div class="mb-3">
            <label class="form-label">Ürün Adı</label>
            <input type="text" name="name" class="form-control" value="<?= htmlspecialchars($product['name']) ?>" required>
        </div>

        <div class="mb-3">
            <label class="form-label">Açıklama</label>
            <textarea name="description" class="form-control"><?= htmlspecialchars($product['description']) ?></textarea>
        </div>

        <div class="mb-3">
            <label class="form-label">Fiyat</label>
            <input type="number" step="0.01" name="price" class="form-control" value="<?= $product['price'] ?>" required>
        </div>

        <div class="mb-3">
            <label class="form-label">Kategori</label>
            <select name="category_id" class="form-select">
                <?php
                $cats = $pdo->query("SELECT * FROM categories");
                foreach ($cats as $cat): ?>
                    <option value="<?= $cat['id'] ?>" <?= $cat['id'] == $product['category_id'] ? 'selected' : '' ?>>
                        <?= htmlspecialchars($cat['name']) ?>
                    </option>
                <?php endforeach; ?>
            </select>
        </div>

        <div class="mb-3">
            <label class="form-label">Marka</label>
            <select name="brand_id" class="form-select">
                <?php
                $brands = $pdo->query("SELECT * FROM brands");
                foreach ($brands as $brand): ?>
                    <option value="<?= $brand['id'] ?>" <?= $brand['id'] == $product['brand_id'] ? 'selected' : '' ?>>
                        <?= htmlspecialchars($brand['name']) ?>
                    </option>
                <?php endforeach; ?>
            </select>
        </div>

        <div class="mb-3">
            <label class="form-label">Resim Yolu</label>
            <input type="text" name="image" class="form-control" value="<?= htmlspecialchars($product['image']) ?>">
        </div>

        <button type="submit" class="btn btn-success">Kaydet</button>
        <a href="admin_panel.php" class="btn btn-secondary">İptal</a>
    </form>
</div>

</body>
</html>
