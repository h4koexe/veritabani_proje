<footer class="bg-dark text-white py-4 mt-5">
    <div class="container">
        <div class="row">
            <div class="col-md-4">
                <h5>TrimechA</h5>
                <p>Bilgisayar satış ve tamir hizmetlerinde güvenilir adres.</p>
            </div>
            <div class="col-md-4">
                <h5>Hızlı Linkler</h5>
                <ul class="list-unstyled">
                    <li><a href="index.php" class="text-white-50">Ana Sayfa</a></li>
                    <li><a href="listing.php" class="text-white-50">Ürünler</a></li>
                    <li><a href="#services" class="text-white-50">Hizmetler</a></li>
                    <li><a href="contact.php" class="text-white-50">İletişim</a></li>
                </ul>
            </div>
            <div class="col-md-4">
                <h5>İletişim</h5>
                <p><i class="bi bi-telephone"></i> 0555 123 4567</p>
                <p><i class="bi bi-envelope"></i> info@trimecha.com</p>
                <p><i class="bi bi-geo-alt"></i> Ankara, Türkiye</p>
            </div>
        </div>
        <hr class="bg-white">
        <div class="text-center">
            <small>&copy; <?= date('Y') ?> TrimechA. Tüm hakları saklıdır.</small>
        </div>
    </div>
</footer>
