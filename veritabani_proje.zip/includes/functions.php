<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

require_once 'config.php';

function requireLogin() {
    if (!isset($_SESSION['user_id'])) {
        header('Location: login.php');
        exit;
    }
}

function getUserName($pdo, $user_id) {
    $stmt = $pdo->prepare("SELECT username FROM users WHERE id = ?");
    $stmt->execute([$user_id]);
    $user = $stmt->fetch();
    return $user ? $user['username'] : 'Kullanıcı';
}

function getProducts($pdo) {
    $stmt = $pdo->query("SELECT p.*, c.name AS category, b.name AS brand
                         FROM products p
                         LEFT JOIN categories c ON p.category_id = c.id
                         LEFT JOIN brands b ON p.brand_id = b.id");
    return $stmt->fetchAll();
}

function getCartItems($pdo, $user_id) {
    $stmt = $pdo->prepare("SELECT c.*, p.name, p.price, p.image
                           FROM cart c
                           JOIN products p ON c.product_id = p.id
                           WHERE c.user_id = ?");
    $stmt->execute([$user_id]);
    return $stmt->fetchAll();
}

function getCartTotal($pdo, $user_id) {
    $stmt = $pdo->prepare("SELECT SUM(p.price * c.quantity) AS total
                           FROM cart c
                           JOIN products p ON c.product_id = p.id
                           WHERE c.user_id = ?");
    $stmt->execute([$user_id]);
    $row = $stmt->fetch();
    return $row['total'] ?? 0;
}

function getFavorites($pdo, $user_id) {
    $stmt = $pdo->prepare("SELECT f.*, p.name, p.price, p.image
                           FROM favorites f
                           JOIN products p ON f.product_id = p.id
                           WHERE f.user_id = ?");
    $stmt->execute([$user_id]);
    return $stmt->fetchAll();
}
