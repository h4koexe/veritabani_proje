<?php
session_start();
require_once 'includes/config.php';
require_once 'includes/functions.php';

$user_id = $_SESSION['user_id'] ?? null;
$username = $user_id ? getUserName($pdo, $user_id) : null;

// Kategoriler
$categories = $pdo->query("SELECT * FROM categories LIMIT 5")->fetchAll();
$products = getProducts($pdo);
$services = $pdo->query("SELECT * FROM services")->fetchAll();
?>

<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="UTF-8">
    <title>Trimecha - Bilgisayar Teknik Servis & Satış</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.0/font/bootstrap-icons.css">
</head>
<body class="bg-light">

<nav class="navbar navbar-expand-lg navbar-dark bg-dark">
  <div class="container">
    <a class="navbar-brand" href="index.php">Trimecha</a>
    <form class="d-flex ms-auto me-3" action="search.php" method="get">
      <input class="form-control me-2" type="search" name="q" placeholder="Ürün ara..." aria-label="Search">
      <button class="btn btn-outline-light" type="submit">Ara</button>
    </form>
    <ul class="navbar-nav">
      <li class="nav-item"><a class="nav-link" href="favorites.php"><i class="bi bi-heart"></i></a></li>
      <li class="nav-item"><a class="nav-link" href="cart.php"><i class="bi bi-cart"></i></a></li>
      <?php if ($username): ?>
        <li class="nav-item"><span class="nav-link text-white">Merhaba, <?= htmlspecialchars($username) ?></span></li>
        <li class="nav-item"><a class="nav-link" href="dashboard.php">Panel</a></li>
        <li class="nav-item"><a class="nav-link" href="logout.php">Çıkış Yap</a></li>
      <?php else: ?>
        <li class="nav-item"><a class="nav-link" href="login.php">Giriş Yap</a></li>
        <li class="nav-item"><a class="nav-link" href="register.php">Üye Ol</a></li>
      <?php endif; ?>
    </ul>
  </div>
</nav>
