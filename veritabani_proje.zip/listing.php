<?php
require_once 'includes/config.php';
require_once 'includes/functions.php';

$products = getProducts($pdo);
$user_id = $_SESSION['user_id'] ?? null;

// Sepet ve favori işlemleri
if ($_SERVER['REQUEST_METHOD'] === 'POST' && $user_id) {
    $product_id = $_POST['product_id'] ?? 0;

    if (isset($_POST['add_to_cart'])) {
        $stmt = $pdo->prepare("INSERT INTO cart (user_id, product_id, quantity) VALUES (?, ?, 1)
                               ON DUPLICATE KEY UPDATE quantity = quantity + 1");
        $stmt->execute([$user_id, $product_id]);
    }

    if (isset($_POST['add_to_favorites'])) {
        $stmt = $pdo->prepare("SELECT id FROM favorites WHERE user_id = ? AND product_id = ?");
        $stmt->execute([$user_id, $product_id]);
        if (!$stmt->fetch()) {
            $stmt = $pdo->prepare("INSERT INTO favorites (user_id, product_id) VALUES (?, ?)");
            $stmt->execute([$user_id, $product_id]);
        }
    }

    header("Location: listing.php");
    exit;
}
?>

<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Ürünler - Trimecha</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="bg-light">

<div class="container mt-4">
    <h2 class="mb-4">Ürünler</h2>

    <div class="row">
        <?php foreach ($products as $product): ?>
        <div class="col-md-4 mb-4">
            <div class="card shadow-sm h-100">
                <img src="<?= htmlspecialchars($product['image']) ?>" class="card-img-top" alt="<?= $product['name'] ?>" style="height: 200px; object-fit: cover;">
                <div class="card-body d-flex flex-column">
                    <h5 class="card-title"><?= htmlspecialchars($product['name']) ?></h5>
                    <p class="card-text">Kategori: <?= htmlspecialchars($product['category']) ?><br>
                    Marka: <?= htmlspecialchars($product['brand']) ?><br>
                    <strong>₺<?= number_format($product['price'], 2) ?></strong></p>

                    <?php if ($user_id): ?>
                    <form method="POST" class="mt-auto">
                        <input type="hidden" name="product_id" value="<?= $product['id'] ?>">
                        <div class="d-grid gap-2">
                            <button type="submit" name="add_to_cart" class="btn btn-primary">Sepete Ekle</button>
                            <button type="submit" name="add_to_favorites" class="btn btn-outline-danger">Favorilere Ekle</button>
                        </div>
                    </form>
                    <?php else: ?>
                        <div class="alert alert-info mt-3">Giriş yaparak işlem yapabilirsiniz.</div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
        <?php endforeach; ?>
    </div>

    <a href="dashboard.php" class="btn btn-secondary mt-3">Geri Dön</a>
</div>

</body>
</html>
